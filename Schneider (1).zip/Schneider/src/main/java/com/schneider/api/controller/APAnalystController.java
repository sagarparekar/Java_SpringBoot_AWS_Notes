package com.schneider.api.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.schneider.api.dto.ap.LogisticDataDTO;
import com.schneider.api.dto.ap.LogisticsSubmitDTO;
import com.schneider.api.dto.ap.PoDTO;
import com.schneider.api.dto.ap.PurchaseOrderDTO;
import com.schneider.api.service.impl.APPurchaseOrderServiceImpl;
import com.sun.xml.bind.v2.TODO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.*;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.multipart.MultipartFile;

import java.io.File;
import java.io.IOException;
import java.math.BigInteger;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@CrossOrigin
@RestController
@RequestMapping("/ap")
public class APAnalystController {
    private static final Logger LOG = LoggerFactory.getLogger(APAnalystController.class);
    @Autowired
    APPurchaseOrderServiceImpl apPurchaseOrderServiceImpl;

    @Value("${default.packing.file.upload.location}")
    private String fileUploadPath;

    /**
     * AP Dashboard - search PO API
     * Author - Sagar
     */
    @GetMapping("/consume-purchaseOrder")
    @PreAuthorize("hasAuthority('AP ANALYST')")
    public ResponseEntity<List<PurchaseOrderDTO>> consumePurchaseOrderGetApi(@RequestParam("fromDate") String fromDate, @RequestParam("toDate") String toDate) throws JsonProcessingException {
        //creating a dummy response here
        List<PurchaseOrderDTO> purchaseOrderList = new ArrayList<>();
        PurchaseOrderDTO purchaseOrder = new PurchaseOrderDTO();
        purchaseOrder.setPoNo("1122");
        purchaseOrder.setAddress("Pune");
        purchaseOrder.setName("Sagar");
        purchaseOrder.setPrice(1223.32);
        purchaseOrder.setQuantity("2");
        purchaseOrder.setDeliveryDate(new Date());
        purchaseOrder.setSubmissionDate(new Date());
        purchaseOrder.setStatus("Purchased");
        purchaseOrder.setLineItemNo("LIN9878");
        purchaseOrder.setMaterialNo("MN142342");
        purchaseOrder.setCompanyCode("23");
        purchaseOrderList.add(purchaseOrder);

        return new ResponseEntity<>(purchaseOrderList, HttpStatus.OK);

    }

    /**
     * AP Dashboard - Submit PO API
     * Author - Sagar
     */
    @PostMapping("/consume-submit-po")
    @PreAuthorize("hasAuthority('AP ANALYST')")
    public ResponseEntity<?> consumeSubmitPO(@RequestBody PoDTO poDTO) {
//        try {
//            String response = new RestTemplate().postForObject("http://localhost:8081/dummy/submitPO", poDTO, String.class);
//            return ResponseEntity.ok("Purchase Order submitted successfully..!!");
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//        return ResponseEntity.status(HttpStatus.NO_CONTENT).body("Response object is null");
        /*
        TODO Sagar: for testing purpose syso used after checking need to remove
           */
        System.out.println("poNo="+ poDTO.getPoNo());
        LOG.info("poNo="+ poDTO.getPoNo());

        return ResponseEntity.ok("PO Data Submitted Successfully");
    }


    /**
     * AP Dashboard -  Logistic Data search API
     * Author - Sagar
     */
    @GetMapping("/consume-logistic-data")
    @PreAuthorize("hasAuthority('AP ANALYST')")
    public ResponseEntity<List<LogisticDataDTO>> consumeLogisticDataGetApi(@RequestParam("fromDate") String fromDate, @RequestParam("toDate") String toDate) throws JsonProcessingException {
       // return new ResponseEntity<>(apPurchaseOrderServiceImpl.getLogisticData(fromDate, toDate), HttpStatus.OK);
        List<LogisticDataDTO> logisticDataList = new ArrayList<>();
        LogisticDataDTO logisticData = new LogisticDataDTO();
        logisticData.setPoNo("4444");
        logisticData.setGrnNo("34gdgd");
        logisticData.setQty(5);
        logisticData.setName("Logistic Data");
        logisticData.setActualDeliveryDate(new Date());
        logisticData.setStatus("Recieved");
        logisticData.setSubmissionDate(new Date());
        logisticData.setDeliveryDate(new Date());
        logisticData.setBoe("test");
        logisticData.setDeliveryNo("wddsd");
        logisticData.setAddress("Pune");
        logisticData.setPackingList("SGH,HHJ");
        logisticDataList.add(logisticData);
        return new ResponseEntity<>(logisticDataList, HttpStatus.OK);
    }

    /**
     * AP Dashboard - Submit Logistics API
     * Author - Barkha
     */
    @PostMapping("/consume-submit-logistics")
    @PreAuthorize("hasAuthority('AP ANALYST')")
    public ResponseEntity<?> consumeSubmitLogistic(@RequestBody LogisticsSubmitDTO logDTO) {

        System.out.println("grnno="+ logDTO.getGrnNo());
        LOG.info("grnno="+ logDTO.getGrnNo());

        return ResponseEntity.ok("Logistics Submitted Successfully");
    }

    /**
     * AP Dashboard - Upload packing list in Submit Logistics API
     * Author - Barkha
    TODO Barkha: Check with Purbaja about storing the file info in local database??
     */
    @PostMapping("/upload-packing-list")
    @PreAuthorize("hasAuthority('AP ANALYST')")
    public ResponseEntity<?> uploadPackingList(@RequestParam("file") MultipartFile file)
            throws IOException, NoSuchAlgorithmException {

        //Save the packing list file locally
        String fileName = file.getOriginalFilename();
        try {
            file.transferTo( new File(fileUploadPath + fileName));
        } catch (Exception e) {
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }

        //Get the checksum of saved file
        String filePath = fileUploadPath + fileName;
        byte[] data = Files.readAllBytes(Path.of(filePath));
        byte[] hash = MessageDigest.getInstance("SHA-256").digest(data);
        String checksum = new BigInteger(1, hash).toString(16);
        System.out.println("Checksum = "+checksum);
        LOG.info("Checksum = "+checksum);

        return new ResponseEntity<>("{\"checksum\" : "+checksum+"}", HttpStatus.OK);
    }
}