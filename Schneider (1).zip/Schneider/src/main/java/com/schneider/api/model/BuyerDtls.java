package com.schneider.api.model;

public class BuyerDtls {

    private String gstin;

    private String lglNm;

    private String trdNm;

    private String pos;

    private String addr1;

    private String addr2;

    private String loc;

    private int pin;

    private String stcd;

    private String pn;

    private String em;

    public String getGstin() {
        return gstin;
    }

    public void setGstin(String gstin) {
        this.gstin = gstin;
    }

    public String getLglNm() {
        return lglNm;
    }

    public void setLglNm(String lglNm) {
        this.lglNm = lglNm;
    }

    public String getTrdNm() {
        return trdNm;
    }

    public void setTrdNm(String trdNm) {
        this.trdNm = trdNm;
    }

    public String getPos() {
        return pos;
    }

    public void setPos(String pos) {
        this.pos = pos;
    }

    public String getAddr1() {
        return addr1;
    }

    public void setAddr1(String addr1) {
        this.addr1 = addr1;
    }

    public String getAddr2() {
        return addr2;
    }

    public void setAddr2(String addr2) {
        this.addr2 = addr2;
    }

    public String getLoc() {
        return loc;
    }

    public void setLoc(String loc) {
        this.loc = loc;
    }

    public int getPin() {
        return pin;
    }

    public void setPin(int pin) {
        this.pin = pin;
    }

    public String getStcd() {
        return stcd;
    }

    public void setStcd(String stcd) {
        this.stcd = stcd;
    }

    public String getPn() {
        return pn;
    }

    public void setPn(String pn) {
        this.pn = pn;
    }

    public String getEm() {
        return em;
    }

    public void setEm(String em) {
        this.em = em;
    }
}