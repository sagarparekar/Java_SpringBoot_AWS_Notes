package com.schneider.api.dto.ap;

import org.springframework.data.annotation.Transient;

import java.util.Date;

public class LogisticsSubmitDTO {

    private String grnNo;

    @Transient
    private String billOfEntry;

    private String poNo;

    private int qty;

    private String name;

    private String address;

    private Date deliveryDateOfPO;

    private Date actualDeliveryDate;

    private String deliveryNumber;

    public String getGrnNo() {
        return grnNo;
    }

    public void setGrnNo(String grnNo) {
        this.grnNo = grnNo;
    }

    public String getBillOfEntry() {
        return billOfEntry;
    }

    public void setBillOfEntry(String billOfEntry) {
        this.billOfEntry = billOfEntry;
    }

    public String getPoNo() {
        return poNo;
    }

    public void setPoNo(String poNo) {
        this.poNo = poNo;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public Date getDeliveryDateOfPO() {
        return deliveryDateOfPO;
    }

    public void setDeliveryDateOfPO(Date deliveryDateOfPO) {
        this.deliveryDateOfPO = deliveryDateOfPO;
    }

    public Date getActualDeliveryDate() {
        return actualDeliveryDate;
    }

    public void setActualDeliveryDate(Date actualDeliveryDate) {
        this.actualDeliveryDate = actualDeliveryDate;
    }

    public String getDeliveryNumber() { return deliveryNumber; }

    public void setDeliveryNumber(String deliveryNumber) { this.deliveryNumber = deliveryNumber; }
}
