package com.schneider.api.service.impl;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.schneider.api.controller.APAnalystController;
import com.schneider.api.dto.ap.LogisticDataDTO;
import com.schneider.api.dto.ap.PurchaseOrderDTO;
import com.schneider.api.exception.BlockchainException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.*;
import org.springframework.stereotype.Service;
import org.springframework.web.client.HttpServerErrorException;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;

import java.util.ArrayList;
import java.util.List;

@Service
public class APPurchaseOrderServiceImpl {

    private static final Logger LOG = LoggerFactory.getLogger(APPurchaseOrderServiceImpl.class);

    // AP Dashboard - Search PO Details on the basis of fromDate and toDate
    // Auther - Sagar

//    public List<PurchaseOrderDTO> getPurchaseOrderList(String fromDate, String toDate) throws JsonProcessingException {
//        List<PurchaseOrderDTO> purchaseOrderDTOList = new ArrayList<>();
//        final HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_JSON);
//        final HttpEntity entity = new HttpEntity(headers);
//        //To call third party API Using RestTemplate
//        RestTemplate restTemplate = new RestTemplate();
//        final String GET_PURCHASE_ORDER_ENDPOINT_URL = "http://localhost:8081/dummy/getPO" + "?fromDate=" + fromDate + "&toDate=" + toDate;
//        ResponseEntity<String> responseEntity = restTemplate.exchange(GET_PURCHASE_ORDER_ENDPOINT_URL, HttpMethod.GET, entity, String.class);
//        if (responseEntity != null && responseEntity.getStatusCode().equals(HttpStatus.OK)) {
//            responseEntity.getBody();
//            LOG.info("Checking responseEntity Data : " + responseEntity.getBody());
//            // Parsing JSON to Object
//            ObjectMapper objectMapper = new ObjectMapper();
//            List<PurchaseOrderDTO> purchaseOrderDTO = objectMapper.readValue(responseEntity.getBody(), List.class);
//            LOG.info("Checking Data Inside purchaseOrderDTO : " + purchaseOrderDTO);
//            purchaseOrderDTOList.addAll(purchaseOrderDTO);
//        }
//        return purchaseOrderDTOList;
//    }

    // AP Dashboard - Search PO Details on the basis of fromDate and toDate
    // Auther - Sagar
    public List<PurchaseOrderDTO> getPurchaseOrderList(String fromDate, String toDate) throws JsonProcessingException {
        var headers = new HttpHeaders();
        headers.setContentType(MediaType.APPLICATION_JSON);
        var entity = new HttpEntity<>(headers);
        var restTemplate = new RestTemplate();
        var url = "http://localhost:8081/dummy/getPO?fromDate=" + fromDate + "&toDate=" + toDate;
        try {
            var response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
            if (response != null && response.getStatusCode().is2xxSuccessful()) {
                var responseBody = response.getBody();
                var purchaseOrderDTOList = new ObjectMapper().readValue(responseBody, new TypeReference<>() {
                });
                return (List<PurchaseOrderDTO>) purchaseOrderDTOList;
            }
        } catch (HttpServerErrorException e) {
            throw new BlockchainException("Blockchain server down!!");
        } catch (RestClientException e) {
            // handle other REST API related exceptions
        }
        return List.of();
    }


    // AP Dashboard - Search Logistic Data on the basis of fromDate and toDate
//    public List<LogisticDataDTO> getLogisticData(String fromDate, String toDate) throws JsonProcessingException {
//        List<LogisticDataDTO> LogisticDataDTOList = new ArrayList<>();
//        final HttpHeaders headers = new HttpHeaders();
//        headers.setContentType(MediaType.APPLICATION_JSON);
//        final HttpEntity entity = new HttpEntity(headers);
//        //To call third party API Using RestTemplate
//        RestTemplate restTemplate = new RestTemplate();
//        final String GET_LOGISTIC_DATA_ENDPOINT_URL = "http://localhost:8081/dummy/get-logistic-data" + "?fromDate=" + fromDate + "&toDate=" + toDate;
//        ResponseEntity<String> responseEntity = restTemplate.exchange(GET_LOGISTIC_DATA_ENDPOINT_URL, HttpMethod.GET, entity, String.class);
//        if (responseEntity != null && responseEntity.getStatusCode().equals(HttpStatus.OK)) {
//            responseEntity.getBody();
//            // Parsing JSON to Object
//            ObjectMapper objectMapper = new ObjectMapper();
//            List<LogisticDataDTO> logisticDataDTO = objectMapper.readValue(responseEntity.getBody(), List.class);
//            LogisticDataDTOList.addAll(logisticDataDTO);
//        }
//        return LogisticDataDTOList;
//    }


    // AP Dashboard - Search Logistic Data on the basis of fromDate and toDate
    public List<LogisticDataDTO> getLogisticData(String fromDate, String toDate) {
        try {
            var headers = new HttpHeaders();
            headers.setContentType(MediaType.APPLICATION_JSON);
            var entity = new HttpEntity<>(headers);
            var restTemplate = new RestTemplate();
            var url = "http://localhost:8081/dummy/get-logistic-data?fromDate=" + fromDate + "&toDate=" + toDate;
            var response = restTemplate.exchange(url, HttpMethod.GET, entity, String.class);
            if (response != null && response.getStatusCode().equals(HttpStatus.OK)) {
                var responseBody = response.getBody();
                var logisticDataDTO = new ObjectMapper().readValue(responseBody, new TypeReference<>() {
                });
                return (List<LogisticDataDTO>) logisticDataDTO;
            }
        } catch (RestClientException | JsonProcessingException e) {
            throw new BlockchainException("Blockchain server not connected please check!!");
        }
        return List.of();
    }


}