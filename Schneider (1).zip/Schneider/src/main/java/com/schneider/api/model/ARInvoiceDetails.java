package com.schneider.api.model;

import javax.persistence.*;
import java.util.Date;

@Entity
@Table(name = "AR_INVOICE_DETAIL")
public class ARInvoiceDetails {
    @Id
    @GeneratedValue
    @Column(name = "ID")
    private int id;
    @Column(name = "Invoice_No", length = 100)
    private String invoiceNo;
    @Column(name = "Invoice_Date")
    private Date invoiceDate;

    @Column(name = "Invoice", length = 8000)
    private String invoice;//change to invoice // base 64 encode json string

    @Column(name = "Ack_Token", length = 100)
    private String ackToken;
    @Column(name = "PO_Number")
    private String poNumber;

    @Column(name = "Goods_Shipped_Date")
    private Date goodsShippedDate;
    @Column(name = "Invoice_Amount")
    private int invoiceAmount;
    @Column(name = "Invoice_Status")
    private String invoiceStatus;
    @Column(name = "Payment_Status")
    private String paymentStatus;
    @Column(name = "Status", length = 100)
    private String status;//hardcoded as invoice recd
    @Column(name = "Created_On")
    private Date createdOn;
    @Column(name = "Last_Updated_On")
    private Date lastUpdatedOn;

    @Column(name = "Name")
    private String name;
    @Column(name = "Address")
    private String address;
    @Column(name = "DeliveryDate")
    private String deliveryDate;
    @Column(name = "Qty")
    private int qty;
    @Column(name = "Price")
    private double price;
    @Column(name = "DeliveryNo")
    private String deliveryNo;

    public Date getInvoiceDate() {
        return invoiceDate;
    }

    public void setInvoiceDate(Date invoiceDate) {
        this.invoiceDate = invoiceDate;
    }

    public String getPoNumber() {
        return poNumber;
    }

    public void setPoNumber(String poNumber) {
        this.poNumber = poNumber;
    }

    public Date getGoodsShippedDate() {
        return goodsShippedDate;
    }

    public void setGoodsShippedDate(Date goodsShippedDate) {
        this.goodsShippedDate = goodsShippedDate;
    }

    public int getInvoiceAmount() {
        return invoiceAmount;
    }

    public void setInvoiceAmount(int invoiceAmount) {
        this.invoiceAmount = invoiceAmount;
    }

    public String getInvoiceStatus() {
        return invoiceStatus;
    }

    public void setInvoiceStatus(String invoiceStatus) {
        this.invoiceStatus = invoiceStatus;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getInvoiceNo() {
        return invoiceNo;
    }

    public void setInvoiceNo(String invoiceNo) {
        this.invoiceNo = invoiceNo;
    }

    public String getInvoice() {
        return invoice;
    }

    public void setInvoice(String invoice) {
        this.invoice = invoice;
    }

    public String getAckToken() {
        return ackToken;
    }

    public void setAckToken(String ackToken) {
        this.ackToken = ackToken;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public Date getCreatedOn() {
        return createdOn;
    }

    public void setCreatedOn(Date createdOn) {
        this.createdOn = createdOn;
    }

    public Date getLastUpdatedOn() {
        return lastUpdatedOn;
    }

    public void setLastUpdatedOn(Date lastUpdatedOn) {
        this.lastUpdatedOn = lastUpdatedOn;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDeliveryNo() {
        return deliveryNo;
    }

    public void setDeliveryNo(String deliveryNo) {
        this.deliveryNo = deliveryNo;
    }
}