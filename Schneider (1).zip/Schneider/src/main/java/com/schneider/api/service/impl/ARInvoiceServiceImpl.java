package com.schneider.api.service.impl;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.schneider.api.dto.ARInvoiceDetailsDto;
import com.schneider.api.dto.SubmitInvoiceDTO;
import com.schneider.api.exception.FileNotFoundException;
import com.schneider.api.model.ARInvoiceDetails;
import com.schneider.api.repo.ARInvoiceRepo;
import com.schneider.api.service.ARInvoiceService;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.net.MalformedURLException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.*;

@Service
public class ARInvoiceServiceImpl implements ARInvoiceService {
    private static final Logger LOG = LoggerFactory.getLogger(ARInvoiceServiceImpl.class);

    @Autowired
    ARInvoiceRepo arInvoiceRepo;

    @Value("${default.file.location}")
    private String fileLocation;

    /**
     * validating json and encoding to base64 and storing in ar_invoice_details table
     *
     * @return submitInvoiceDto with hard coded status as INVOICE_RECEIVED
     */
    @Override
    public ARInvoiceDetails saveARInvoiceDetails(SubmitInvoiceDTO submitInvoiceDTO) throws ParseException {
        Date dNow = new Date();
        SimpleDateFormat ft = new SimpleDateFormat("yyMMddhhmmssMs");
        String ackToken = ft.format(dNow);
        ARInvoiceDetails arInvoiceDetails = new ARInvoiceDetails();
        arInvoiceDetails.setInvoiceNo(submitInvoiceDTO.getDocDtls().getNo());

        arInvoiceDetails.setInvoiceDate(new SimpleDateFormat("dd/MM/yyyy").parse(submitInvoiceDTO.getDocDtls().getDt()));
        ObjectMapper Obj = new ObjectMapper();
        try {
            // Converting the Java object into a JSON string
            String jsonStr = Obj.writeValueAsString(submitInvoiceDTO);

            String encodedString = Base64.getEncoder().encodeToString(jsonStr.getBytes());

            arInvoiceDetails.setInvoice(encodedString);

        } catch (IOException e) {
            e.printStackTrace();
        }
        arInvoiceDetails.setAckToken(ackToken);
        arInvoiceDetails.setPoNumber(submitInvoiceDTO.getRefDtls().getContrDtls().get(0).getPoRefr());
        arInvoiceDetails.setGoodsShippedDate(new SimpleDateFormat("dd/MM/yyyy").parse(submitInvoiceDTO.getExpDtls().getShipBDt()));
        arInvoiceDetails.setInvoiceAmount((int) submitInvoiceDTO.getValDtls().getTotInvVal());
        arInvoiceDetails.setInvoiceStatus(submitInvoiceDTO.getRefDtls().getInvRm());
        arInvoiceDetails.setPaymentStatus(submitInvoiceDTO.getPayDtls().getMode());
        arInvoiceDetails.setCreatedOn(dNow);
        arInvoiceDetails.setLastUpdatedOn(dNow);
        arInvoiceDetails.setStatus("INVOICE_RECEIVED");
        if (Objects.nonNull(submitInvoiceDTO.getDeliveryDate())) {
            arInvoiceDetails.setDeliveryDate(submitInvoiceDTO.getDeliveryDate());
        }
        arInvoiceDetails.setDeliveryNo(submitInvoiceDTO.getDeliveryNo());
        arInvoiceDetails.setAddress(submitInvoiceDTO.getAddress());
        arInvoiceDetails.setName(submitInvoiceDTO.getName());
        arInvoiceDetails.setQty(submitInvoiceDTO.getQty());
        arInvoiceDetails.setPrice(submitInvoiceDTO.getPrice());
        return arInvoiceRepo.save(arInvoiceDetails);
    }

    /**
     * @return List of all AR_Invoice_Details table from db
     */
    @Override
    public List<ARInvoiceDetails> getAllARInvoiceDetails(Integer pageNumber, Integer pageSize) {
        Pageable p = PageRequest.of(pageNumber, pageSize);
        Page<ARInvoiceDetails> ARInvoiceDetailsList = arInvoiceRepo.findAll(p);
        List<ARInvoiceDetails> arInvoiceDetailsListContent = ARInvoiceDetailsList.getContent();
        return arInvoiceDetailsListContent;
    }

    /**
     * return AR Analyst Dashboard Data on the basis of date
     * pagenumber=1, pageSzie=10
     */
    @Override
    public List<ARInvoiceDetailsDto> getDataByInvoiceDate(Date fromDate, Date toDate) {

        List<ARInvoiceDetailsDto> arInvoiceDetailsDtos = new ArrayList<>();
        List<ARInvoiceDetails> dataByInvoiceDate = arInvoiceRepo.getDataByInvoiceDate(fromDate, toDate);
        for (ARInvoiceDetails arInvoiceDetails : dataByInvoiceDate) {
            ARInvoiceDetailsDto dto = new ARInvoiceDetailsDto();
            dto.setInvoiceNo(arInvoiceDetails.getInvoiceNo());
            dto.setInvoiceDate(arInvoiceDetails.getInvoiceDate());
            dto.setInvoiceAmount(arInvoiceDetails.getInvoiceAmount());
            dto.setInvoiceStatus(arInvoiceDetails.getInvoiceStatus());
            dto.setPoNumber(arInvoiceDetails.getPoNumber());
            dto.setGoodsShippedDate(arInvoiceDetails.getGoodsShippedDate());
            dto.setPaymentStatus(arInvoiceDetails.getPaymentStatus());
            dto.setAddress(arInvoiceDetails.getAddress());
            dto.setDeliveryDate(arInvoiceDetails.getDeliveryDate());
            dto.setDeliveryNo(arInvoiceDetails.getDeliveryNo());
            dto.setQty(arInvoiceDetails.getQty());
            dto.setPrice(arInvoiceDetails.getPrice());
            dto.setName(arInvoiceDetails.getName());
            arInvoiceDetailsDtos.add(dto);

        }

        return arInvoiceDetailsDtos;
    }

    /**
     * @return getting file location from local storage
     */
    public Resource loadFileAsResource(String fileName) throws IOException {
        Path fileStorageLocation = Paths.get(fileLocation).toAbsolutePath().normalize();
        Optional<Path> filePath = Files.walk(fileStorageLocation)
                .filter(p -> p.getFileName().toString().startsWith(fileName))
                .findFirst();

        if (filePath.isEmpty()) {
            throw new FileNotFoundException("File not found: " + fileName);
        }

        Resource resource = new UrlResource(filePath.get().toUri());
        if (!resource.exists()) {
            throw new FileNotFoundException("File not found: " + fileName);
        }

        return resource;
    }


    @Override
    public List<String> getInvoiceNoByStatus() {
        return arInvoiceRepo.getDataByStatus();
    }


}