package com.schneider.api.dto;

import com.fasterxml.jackson.annotation.JsonProperty;


public class TaxInvoiceDTO {
	
	@JsonProperty("AckNo")
	private Long ackNo;
	@JsonProperty("AckDt")
	private String ackDt;
	@JsonProperty("Irn")
	private String irn;
	@JsonProperty("SignedInvoice")
	private String signedInvoice;
	@JsonProperty("SignedQRCode")
	private String signedQRCode;
	@JsonProperty("Status")
	private String status;
	@JsonProperty("EwbNo")
	private Long ewbNo;
	@JsonProperty("EwbDt")
	private String ewbDt;
	@JsonProperty("EwbValidTill")
	private String ewbValidTill;
	@JsonProperty("Remarks")
	private String remarks;
	public Long getAckNo() {
		return ackNo;
	}
	public void setAckNo(Long ackNo) {
		this.ackNo = ackNo;
	}
	public String getAckDt() {
		return ackDt;
	}
	public void setAckDt(String ackDt) {
		this.ackDt = ackDt;
	}
	public String getIrn() {
		return irn;
	}
	public void setIrn(String irn) {
		this.irn = irn;
	}
	public String getSignedInvoice() {
		return signedInvoice;
	}
	public void setSignedInvoice(String signedInvoice) {
		this.signedInvoice = signedInvoice;
	}
	public String getSignedQRCode() {
		return signedQRCode;
	}
	public void setSignedQRCode(String signedQRCode) {
		this.signedQRCode = signedQRCode;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Long getEwbNo() {
		return ewbNo;
	}
	public void setEwbNo(Long ewbNo) {
		this.ewbNo = ewbNo;
	}
	public String getEwbDt() {
		return ewbDt;
	}
	public void setEwbDt(String ewbDt) {
		this.ewbDt = ewbDt;
	}
	public String getEwbValidTill() {
		return ewbValidTill;
	}
	public void setEwbValidTill(String ewbValidTill) {
		this.ewbValidTill = ewbValidTill;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	@Override
	public String toString() {
		return "TaxInvoiceDTO [ackNo=" + ackNo + ", ackDt=" + ackDt + ", irn=" + irn + ", signedInvoice=" + signedInvoice
				+ ", signedQRCode=" + signedQRCode + ", status=" + status + ", ewbNo=" + ewbNo + ", ewbDt=" + ewbDt
				+ ", ewbValidTill=" + ewbValidTill + ", remarks=" + remarks + "]";
	}
	
	
}