package com.schneider.api.dto.ap;

import java.util.List;

public class ListOfPO {

    List<PurchaseOrderDTO> purchaseOrderDTOS;
    public List<PurchaseOrderDTO> getPurchaseOrderDTOS() {
        return purchaseOrderDTOS;
    }

    public void setPurchaseOrderDTOS(List<PurchaseOrderDTO> purchaseOrderDTOS) {
        this.purchaseOrderDTOS = purchaseOrderDTOS;
    }



}