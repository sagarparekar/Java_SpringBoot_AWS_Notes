package com.schneider.api.controller;


import com.schneider.api.dto.ARInvoiceDetailsDto;
import com.schneider.api.dto.SubmitInvoiceDTO;
import com.schneider.api.model.ARInvoiceDetails;
import com.schneider.api.dto.TaxInvoiceDTO;
import com.schneider.api.service.ARInvoiceService;
import com.schneider.api.service.impl.TaxInvoiceServiceImpl;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.util.CollectionUtils;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.validation.Valid;
import java.io.IOException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@CrossOrigin
@RestController
@RequestMapping("/schneider")
public class ARAnalystController {

    @Autowired
    ARInvoiceService arInvoiceService;

    @Autowired
    TaxInvoiceServiceImpl taxInvoiceServiceImpl;
    private static final Logger LOG = LoggerFactory.getLogger(ARAnalystController.class);

    /**
     * Storing submit invoice json data (encoded with base64) and Ack token to AR_Invoice_Details Table
     * Author - sagar
     */
    @PostMapping("/submitinvoice")
    @PreAuthorize("hasAnyAuthority('SAP USER', 'AR ANALYST')")
    public ResponseEntity<ARInvoiceDetails> submitInvoice(@Valid @RequestBody SubmitInvoiceDTO submitInvoiceDTO) throws ParseException {

        return ResponseEntity.ok(arInvoiceService.saveARInvoiceDetails(submitInvoiceDTO));
    }

    /**
     * Extra API coded if required then we will use
     *
     * @return fetching List of all data from AR_Invoice_Details Table
     * Author - sagar
     */
    @GetMapping("/getAllARInvoiceDetails")
    //  @PreAuthorize("hasAuthority('AR ANALYST')")
    public ResponseEntity<?> getAllARInvoiceDetails(@RequestParam(value = "pageNumber", defaultValue = "1", required = false) Integer pageNumber, @RequestParam(value = "pageSize", defaultValue = "5", required = false) Integer pageSize) {
        List<ARInvoiceDetails> arInvoiceDetailsList = arInvoiceService.getAllARInvoiceDetails(pageNumber, pageSize);
        if (arInvoiceDetailsList != null) {
            return new ResponseEntity<List<ARInvoiceDetails>>(arInvoiceDetailsList, HttpStatus.OK);
        }
        return new ResponseEntity<String>("ARInvoiceDetailsList is empty", HttpStatus.OK);
    }

    /**
     * @return AR_Analyst Dashboard details on the basis of Date
     * Author- Sagar
     */
    @GetMapping("/getDataByDate")
    @PreAuthorize("hasAuthority('AR ANALYST')")
    public ResponseEntity<String> getDataByInvoiceDate(@RequestParam("fromDate") String fromDate, @RequestParam("toDate") String toDate) throws ParseException {
        if (Objects.isNull(fromDate) || Objects.isNull(toDate)) {
            return ResponseEntity.badRequest().body("toDate or From_date is null ,Please provide dates");
        }
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
        Date toDate1 = simpleDateFormat.parse(toDate);
        Date fromDate1 = simpleDateFormat.parse(fromDate);
        List<ARInvoiceDetailsDto> detailsList = arInvoiceService.getDataByInvoiceDate(fromDate1, toDate1);
        if (CollectionUtils.isEmpty(detailsList)) {
            return ResponseEntity.ok("There is no data found for this dates!");
        }
        return new ResponseEntity(detailsList, HttpStatus.OK);
    }

    /**
     * @return downloaded invoice on the basis of inoviceNo=DOC/003
     * Auther-Sagar
     */
    @GetMapping("/downloadGstInvoice")
    @PreAuthorize("hasAuthority('AR ANALYST')")
    public ResponseEntity<Resource> downloadGstInvoice(@RequestParam String invoiceNo, HttpServletRequest request) throws IOException {
        String name = invoiceNo.replace("/", "");
        Resource resource = arInvoiceService.loadFileAsResource(name);
        String contentType;
        try {
            contentType = request.getServletContext().getMimeType(resource.getFile().getAbsolutePath());
        } catch (IOException ex) {
            LOG.warn("Failed to determine file type for {}", name, ex);
            contentType = "application/octet-stream";
        }
        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(contentType))
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + resource.getFilename() + "\"")
                .body(resource);
    }


    /**
     * converting taxInvoice into pdf format and storing at local storage
     * Author - Ankit
     */
    @GetMapping("/generateTaxInvoice")
//    @PreAuthorize("hasAuthority('AR ANALYST')")
    public void generatedTaxInvoicePdf(@RequestBody TaxInvoiceDTO taxInvoiceDTO, HttpServletResponse response) throws IOException {
        response.setContentType("application/pdf");
        this.taxInvoiceServiceImpl.generatedTaxInvoicePdf(taxInvoiceDTO, response);
    }

    /**
     * @return invoiceNo list from ar_invoice_detail table
     * Author - Ankit
     */
    @GetMapping("/getinvocenumber")
    public ResponseEntity<List<String>> getInvoiceNoByStatus() {
        List<String> invoiceNoList = arInvoiceService.getInvoiceNoByStatus();

        return new ResponseEntity<List<String>>(invoiceNoList, HttpStatus.OK);

    }
}