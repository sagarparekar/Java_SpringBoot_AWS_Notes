package com.schneider.api.dto;

public class AttributeDetailsDTO {
    private String nm;
    private String val;

    public String getNm() {
        return nm;
    }

    public void setNm(String nm) {
        this.nm = nm;
    }

    public String getVal() {
        return val;
    }

    public void setVal(String val) {
        this.val = val;
    }
}