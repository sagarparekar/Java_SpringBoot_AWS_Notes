package com.schneider.api.service.impl;

import com.lowagie.text.*;
import com.lowagie.text.pdf.PdfPCell;
import com.lowagie.text.pdf.PdfPTable;
import com.lowagie.text.pdf.PdfWriter;
import com.schneider.api.dto.TaxInvoiceDTO;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import javax.servlet.http.HttpServletResponse;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

@Service
public class TaxInvoiceServiceImpl {

    @Value("${default.file.location}")
    private String fileLocation;


    public void generatedTaxInvoicePdf(TaxInvoiceDTO taxInvoiceDTO, HttpServletResponse response) throws IOException {

        DateFormat dateFormatter = new SimpleDateFormat("ddMMyyhhmmss");
        String currentDateTime = dateFormatter.format(new Date());
        String headerKey = "Content-Disposition";
        String headerValue = "attachment; filename=Invoice_no_" + currentDateTime + ".pdf";
        response.setHeader(headerKey, headerValue);
        String filename = "Invoice_no_" + currentDateTime + ".pdf";

        //Declaring Font sizes Globally
        Font font20 = FontFactory.getFont(FontFactory.TIMES_BOLD, 20);
        Font font10 = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 10);
        Font font9 = FontFactory.getFont(FontFactory.HELVETICA, 9);
        Font fontItalics8 = FontFactory.getFont(FontFactory.TIMES_ITALIC, 8);
        Font font8 = FontFactory.getFont(FontFactory.TIMES, 8);
        Font fontBold7 = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 7);
        Font font7 = FontFactory.getFont(FontFactory.HELVETICA, 7);
        Font fontItalics5 = FontFactory.getFont(FontFactory.TIMES_ITALIC, 5);
        Font font5 = FontFactory.getFont(FontFactory.TIMES, 5);
        Font font6 = FontFactory.getFont(FontFactory.COURIER, 6);
        Font fontHelvetica6 = FontFactory.getFont(FontFactory.HELVETICA, 6);
        Font fontBold6 = FontFactory.getFont(FontFactory.HELVETICA_BOLD, 6);
        Font fontBold8 = FontFactory.getFont(FontFactory.TIMES_BOLD, 8);

        //Formatting the Document starts here ...
        Document document = new Document(PageSize.A4);
        //To "C:\\Schneider\\GstInvoices\\"
        PdfWriter.getInstance(document, new FileOutputStream(fileLocation + "\\" + filename));
        //opening the document .
        document.open();


        Paragraph px = new Paragraph("ORIGINAL FOR RECIPIENT", fontItalics5);
        px.setAlignment(Paragraph.ALIGN_RIGHT);


        Paragraph paragraph0 = new Paragraph("SCHNEIDER ELECTRIC India PVT. LIMITED", font10);
        paragraph0.setAlignment(Paragraph.ALIGN_CENTER);


        Paragraph paragraph = new Paragraph("Tax Invoice", font20);
        paragraph.setAlignment(Paragraph.ALIGN_CENTER);

        Paragraph paragraphSpace = new Paragraph("\n");


        document.add(px);
        document.add(paragraph0);
        document.add(paragraph);
        document.add(paragraphSpace);

        //creating a table :

        PdfPTable table = new PdfPTable(2);
        PdfPCell cell;
//			Experimental
//			table.addCell("default alignment");
//			table.addCell("paragraph alignment");
        Paragraph p1 = new Paragraph("GSTIN/UniqueID :", fontBold7);
        Paragraph p2 = new Paragraph("Name :", fontBold7);
        Paragraph p3 = new Paragraph("Address :", fontBold7);
        Paragraph p4 = new Paragraph("Irn :", fontBold7);
        cell = new PdfPCell();
        cell.addElement(p1);
        cell.addElement(p2);
        cell.addElement(p3);
        cell.addElement(p4);
        table.addCell(cell);
//			table.addCell("extra indentation (cell)");
        Paragraph p5 = new Paragraph("Invoice Serial No:", font7);
        Paragraph p6 = new Paragraph("Billing Doc No:", font7);
        Paragraph p7 = new Paragraph("Invoice Date:", font7);
        Paragraph p8 = new Paragraph("Delivery Document No:", font7);
        Paragraph p9 = new Paragraph("Sales Order No:", font7);
        Paragraph p10 = new Paragraph("Customer PO Date:", font7);
        Paragraph p11 = new Paragraph("Customer PO No:", font7);
        Paragraph p12 = new Paragraph("Terms of Payment:", font7);
        cell = new PdfPCell();
        cell.addElement(p5);
        cell.addElement(p6);
        cell.addElement(p7);
        cell.addElement(p8);
        cell.addElement(p9);
        cell.addElement(p10);
        cell.addElement(p11);
        cell.addElement(p12);
        table.addCell(cell);


        Paragraph p13 = new Paragraph("NAME AND ADDRESS OF BUYER/PLACE OF SUPPLY:", font9);
        Paragraph p14 = new Paragraph("M/s :", fontBold7);
        Paragraph p15 = new Paragraph("Contact No. :", fontBold7);
        Paragraph p16 = new Paragraph("State Code", fontBold7);
        Paragraph p17 = new Paragraph("GSTIN/Unique ID :", fontBold7);
        Paragraph p18 = new Paragraph("PAN :", fontBold7);
        Paragraph p19 = new Paragraph("Sold-to-party-code :", fontBold7);
        cell = new PdfPCell();
        cell.addElement(p13);
        cell.addElement(p14);
        cell.addElement(p15);
        cell.addElement(p16);
        cell.addElement(p17);
        cell.addElement(p18);
        cell.addElement(p19);


        table.addCell(cell);
        Paragraph p20 = new Paragraph("NAME AND ADDRESS OF SHIP TO PARTY", font9);
        Paragraph p21 = new Paragraph("M/s :", fontBold7);
        Paragraph p22 = new Paragraph("Contact No. :", fontBold7);
        Paragraph p23 = new Paragraph("State Code", fontBold7);
        Paragraph p24 = new Paragraph("GSTIN/Unique ID :", fontBold7);
        Paragraph p25 = new Paragraph("PAN :", fontBold7);
        Paragraph p26 = new Paragraph("Sold-to-party-code :", fontBold7);
        cell = new PdfPCell();
        cell.addElement(p20);
        cell.addElement(p21);
        cell.addElement(p22);
        cell.addElement(p23);
        cell.addElement(p24);
        cell.addElement(p25);
        cell.addElement(p26);
        table.addCell(cell);
        document.add(table);
        //.............................................................................................................//
        //Adding a new Table..

        PdfPTable bTable = new PdfPTable(3);
        cell = new PdfPCell();
        float[] bwidths = {2, 0, 1};
        bTable.setWidths(bwidths);

//			<...................Table 2 - For Shipment No................................>
        //col-1
        Paragraph p27 = new Paragraph("\t\tWeight KG\t\t\tFreight Terms\t\t\tInsurance Terms\t\t\t" + "No. Of Cases\t\t\t Price Basis", font8);
        cell.addElement(p27);
        bTable.addCell(cell);
        cell = new PdfPCell();
        //col-2
        bTable.addCell(cell);
        //col-3
        Paragraph p28 = new Paragraph("Shipment No:", font8);
        cell.addElement(p28);
        bTable.addCell(cell);
        cell = new PdfPCell();

        //ending
        bTable.addCell(cell);
        document.add(bTable);
        //..................................................................................................................//

        //Adding New Table//

        PdfPTable cTable = new PdfPTable(3);
        cell = new PdfPCell();
        float[] cwidths = {2, 1, 0};
        cTable.setWidths(cwidths);

        Paragraph p29 = new Paragraph("\t\t\t\t10.040\t\t\t\t\t\t\t\t\tPRE PAID\t\t\t\t\t\t\t\t\tBY CONSIGNOR\t\t\t\t\t\t\t\t\t\t" + "000001\t\t\t\t\t\t\t\t\t\tCIF", font7);
        cell.addElement(p29);
        cTable.addCell(cell);
        //row -2
        cell = new PdfPCell();
        cTable.addCell(cell);
        //row-3
        cTable.addCell("1.3");
        document.add(cTable);


        //...........................................................................................................//

        PdfPTable dTable = new PdfPTable(11);
        cell = new PdfPCell();
        float[] dwidths = {5, 12, 8, 5, 5, 8, 8, 9, 12, 12, 16};//{5,13,9,10,9,9,9,9,9,9,9}
        dTable.setWidths(dwidths);

        dTable.addCell(new PdfPCell(new Phrase("Line\nNo.", fontBold6)));
        dTable.addCell(new PdfPCell(new Phrase("Description of\nGoods/Services", fontBold6)));
        dTable.addCell(new PdfPCell(new Phrase("HSN/SAC", fontBold6)));
        dTable.addCell(new PdfPCell(new Phrase("UOM", fontBold6)));
        dTable.addCell(new PdfPCell(new Phrase("Qty.", fontBold6)));
        dTable.addCell(new PdfPCell(new Phrase("Unit Price", fontBold6)));
        dTable.addCell(new PdfPCell(new Phrase("Basic Value", fontBold6)));
        dTable.addCell(new PdfPCell(new Phrase("Taxable Value", fontBold6)));
        dTable.addCell(new PdfPCell(new Phrase("Central Tax", fontBold6)));
        dTable.addCell(new PdfPCell(new Phrase("State Tax/Union", fontBold6)));
        dTable.addCell(new PdfPCell(new Phrase("Integrated Tax", fontBold6)));
        document.add(dTable);

        //...........................................................................................................//


        PdfPTable eTable = new PdfPTable(14);
        cell = new PdfPCell();
        float[] ewidths = {5, 12, 8, 5, 5, 8, 8, 9, 6, 6, 6, 6, 8, 8};// 5,12,8,5,5,8,8,9,6,6,6,6,8,8
        eTable.setWidths(ewidths);
        eTable.addCell(new PdfPCell(new Phrase("")));
        eTable.addCell(new PdfPCell(new Phrase("")));
        eTable.addCell(new PdfPCell(new Phrase("")));
        eTable.addCell(new PdfPCell(new Phrase("")));
        eTable.addCell(new PdfPCell(new Phrase("")));
        eTable.addCell(new PdfPCell(new Phrase("")));
        eTable.addCell(new PdfPCell(new Phrase("")));
        eTable.addCell(new PdfPCell(new Phrase("")));
        eTable.addCell(new PdfPCell(new Phrase("Rate%", fontHelvetica6)));
        eTable.addCell(new PdfPCell(new Phrase("Amount", fontHelvetica6)));
        eTable.addCell(new PdfPCell(new Phrase("Rate%", fontHelvetica6)));
        eTable.addCell(new PdfPCell(new Phrase("Amount", fontHelvetica6)));
        eTable.addCell(new PdfPCell(new Phrase("Rate%", fontHelvetica6)));
        eTable.addCell(new PdfPCell(new Phrase("Amount", fontHelvetica6)));
        document.add(eTable);


        //...........................................................................................................//
        PdfPTable fTable = new PdfPTable(14);
        cell = new PdfPCell();
        float[] fwidths = {5, 12, 8, 5, 5, 8, 8, 9, 6, 6, 6, 6, 8, 8};//(First 8 same as dwidths , then remaining 14 = 27/6 = 4(With Adjustments :)
        fTable.setWidths(fwidths);
        fTable.addCell(new PdfPCell(new Phrase("10/1\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", fontHelvetica6)));
        fTable.addCell(new PdfPCell(new Phrase("LC1E80M7\nTVS 3P CTR 400V\n37KW 220V 50/60Hz\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", fontHelvetica6)));
        fTable.addCell(new PdfPCell(new Phrase("85364900\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", fontHelvetica6)));
        fTable.addCell(new PdfPCell(new Phrase("PCE\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", fontHelvetica6)));
        fTable.addCell(new PdfPCell(new Phrase("6.00\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", fontHelvetica6)));
        fTable.addCell(new PdfPCell(new Phrase("5075.40\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", fontHelvetica6)));
        fTable.addCell(new PdfPCell(new Phrase("30452.40\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", fontHelvetica6)));
        fTable.addCell(new PdfPCell(new Phrase("30,452.40\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", fontHelvetica6)));
        fTable.addCell(new PdfPCell(new Phrase("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")));
        fTable.addCell(new PdfPCell(new Phrase("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")));
        fTable.addCell(new PdfPCell(new Phrase("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")));
        fTable.addCell(new PdfPCell(new Phrase("\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n")));
        fTable.addCell(new PdfPCell(new Phrase("18.00%\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", fontHelvetica6)));
        fTable.addCell(new PdfPCell(new Phrase("5,481.43\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n\n", fontHelvetica6)));
        document.add(fTable);


        document.add(paragraphSpace);
        document.add(paragraphSpace);
        document.add(paragraphSpace);
        Paragraph page1 = new Paragraph("Page : 1 of 2", fontBold7);
        page1.setAlignment(Paragraph.ALIGN_RIGHT);
        document.add(page1);
        document.add(paragraphSpace);
        Paragraph pf = new Paragraph("* Disclaimer: By accepting any shipment hereunder, the Consignee acknowledges that the items shipped hereunder may be subject to export-control and economic-sanctions laws" + " and regulations including, but not limited to those of the European Union and member states thereof, the United States, or the United Kingdom. This includes, but is not limited to " + "shipment or transfer to Russia, Belarus, Crimea and other Covered Regions of Ukraine including Donetsk, Kherson, Luhansk and zaporizhzhia, Cuba, Iran, Syria, and North Korea." + "The Consignee agrees and warrants that the items will not be transferred or reexported in any manner that violates, or causes the Shipper to violate, such laws or regulations . ", fontBold8);

        //Adding a new Page .
        document.add(pf);

        //Page - 2.................................................. Begins Here . .............................
        document.newPage();
        document.add(px);
        document.add(paragraph0);
        document.add(paragraph);
        document.add(paragraphSpace);

        cell = new PdfPCell(cell); // refreshing the cell .
        //Calling existing table table ....
        table.addCell(cell);
        document.add(table);

        //adding Spaces..
        document.add(paragraphSpace);
        document.add(paragraphSpace);
        document.add(paragraphSpace);


        //...........................................................................................................//
        PdfPTable gTable = new PdfPTable(8);
        cell = new PdfPCell();
        float[] gwidths = {20, 5, 12, 13, 12, 13, 12, 13};//
        gTable.setWidths(gwidths);
        gTable.addCell(new PdfPCell(new Phrase("")));
        gTable.addCell(new PdfPCell(new Phrase("Qty", font7)));
        gTable.addCell(new PdfPCell(new Phrase("")));
        gTable.addCell(new PdfPCell(new Phrase("Basic Value", font7)));
        gTable.addCell(new PdfPCell(new Phrase("Taxable Value", font7)));
        gTable.addCell(new PdfPCell(new Phrase("")));
        gTable.addCell(new PdfPCell(new Phrase("")));
        gTable.addCell(new PdfPCell(new Phrase("Integrated Tax", font7)));
        document.add(gTable);
        //...........................................................................................................//


        //...........................................................................................................//
        PdfPTable hTable = new PdfPTable(8);
        cell = new PdfPCell();
        float[] hwidths = {20, 5, 12, 13, 12, 13, 12, 13};//
        hTable.setWidths(hwidths);
        hTable.addCell(new PdfPCell(new Phrase("Total", font7)));
        hTable.addCell(new PdfPCell(new Phrase("6.00", font7)));
        hTable.addCell(new PdfPCell(new Phrase("")));
        hTable.addCell(new PdfPCell(new Phrase("30,452.40", font7)));
        hTable.addCell(new PdfPCell(new Phrase("30,452.40", font7)));
        hTable.addCell(new PdfPCell(new Phrase("")));
        hTable.addCell(new PdfPCell(new Phrase("")));
        hTable.addCell(new PdfPCell(new Phrase("5,481.43", font7)));
        document.add(hTable);

        //...........................................................................................................//

        PdfPTable iTable = new PdfPTable(2);
        cell = new PdfPCell();
        float[] iwidths = {25, 75};//
        iTable.setWidths(iwidths);
        iTable.addCell(new PdfPCell(new Phrase("TCS (Tax Collection at Source)", font7)));
        iTable.addCell(new PdfPCell(new Phrase("\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t" + "\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\tNA", font7)));
        document.add(iTable);
        //...........................................................................................................//


        //...........................................................................................................//

        PdfPTable jTable = new PdfPTable(2);
        cell = new PdfPCell();
        float[] jwidths = {25, 75};//
        jTable.setWidths(jwidths);
        jTable.addCell(new PdfPCell(new Phrase("Remarks", font7)));
        jTable.addCell(new PdfPCell(new Phrase("Taxable Value Includes Frieght 0.00 , P&F 0.00 and Surcharge 0.00", font7)));
        document.add(jTable);

        //...........................................................................................................//

        document.add(paragraphSpace);
        document.add(paragraphSpace);
        //...........................................................................................................//

        PdfPTable kTable = new PdfPTable(2);
        cell = new PdfPCell();
        float[] kwidths = {25, 75};//
        kTable.setWidths(kwidths);
        kTable.addCell(new PdfPCell(new Phrase("\n\n\n\n\n\nRemarks", font7)));
        kTable.addCell(new PdfPCell(new Phrase("If TCS is not levied on this Invoice under section 206C(1H) of\n" + "the Income-tax Act, 1961 it is based on the understanding that\n" + "you will deduct tax at source (TDS) u/s 194Q. In case of your\n" + "failure to withhold tax, you shall be liable to indemnify\n" + "seller for TCS liability, interest, penalty if any.\n\n\n\n\n\n\n", font7)));
        document.add(kTable);

        //...........................................................................................................//
        document.add(paragraphSpace);
        //...........................................................................................................//


        //...........................................................................................................//
        PdfPTable lTable = new PdfPTable(3);
        cell = new PdfPCell();
        float[] lwidths = {34, 33, 33};

        cell.setRowspan(5);

        Paragraph p30 = new Paragraph("Transporter's Name:V-Xpress a division of V-Trans", font7);
        cell.addElement(p30);
        Paragraph p31 = new Paragraph("Mode Of Dispatch:Truck", font7);
        cell.addElement(p31);
        Paragraph p32 = new Paragraph("LR/AWB No.:00689070044821411405", font7);
        cell.addElement(p32);
        Paragraph p33 = new Paragraph("Road Permit No:", font7);
        cell.addElement(p33);
        Paragraph p34 = new Paragraph("LC NO:h", font7);
        cell.addElement(p34);
        Paragraph p35 = new Paragraph("Vehicle No:", font7);
        cell.addElement(p35);

        lTable.addCell(cell);

        cell = new PdfPCell();//resetting the cell content


        lTable.addCell(new PdfPCell(new Phrase("Total Invoice Value(In INR)", font7)));
        lTable.addCell(new PdfPCell(new Phrase("35,933.83", font7)));
        lTable.addCell(new PdfPCell(new Phrase("Advance Amount", font7)));
        lTable.addCell(new PdfPCell(new Phrase("0.00", font7)));
        lTable.addCell(new PdfPCell(new Phrase("Retention Amount", font7)));
        lTable.addCell(new PdfPCell(new Phrase("0.00", font7)));
        lTable.addCell(new PdfPCell(new Phrase("Net Recoverable", font7)));
        lTable.addCell(new PdfPCell(new Phrase("35,933.83", font7)));
        lTable.addCell(new PdfPCell(new Phrase("Net Recoverable in Words", font7)));
        lTable.addCell(new PdfPCell(new Phrase("THIRTY FIVE THOUSAND NINE HUNDRED THIRTY THREE Rupees\nEIGHTY THREE Paise only", font7)));
        document.add(lTable);
        //...........................................................................................................//

        document.add(paragraphSpace);

        //...........................................................................................................//

        PdfPTable mTable = new PdfPTable(4);
        cell = new PdfPCell();
        float[] mwidths = {25, 13, 13, 49};
        mTable.setWidths(mwidths);

        mTable.addCell(new PdfPCell(new Phrase("Certified that the particulars given above are true and\n" + "correct and the amount indicated represents the price\n" + "actually charged and there is no flow of additional\n" + "consideration directly or indirectly from the buyer", font6)));
        mTable.addCell((new PdfPCell(new Phrase("Electronic Reference Number:", fontBold7))));
        mTable.addCell((new PdfPCell(new Phrase("Date:", fontBold7))));
        mTable.addCell(new PdfPCell(new Phrase("For Schneider Electric Pvt. Ltd.\n\n\n\n\n\n\n" + "Authorised Signatory", fontBold7)));
        document.add(mTable);

        //...........................................................................................................//

        //...........................................................................................................//

        PdfPTable nTable = new PdfPTable(1);
        cell = new PdfPCell();

        nTable.addCell(new PdfPCell(new Phrase("Registered Office : C-56, Mayapuri Industrial Area,Phase-II,New Delhi-110064 .Corporate Office : 9th Floor, DLF Building No.10,Tower C,DLF Cyber City,Phase .II,Gurgaon-122002,Haryana.\n" + "Tel: +91 124 3940 400\n" + "Email: customercare.IN@schneider-electric.com\n" + "Website: www.schneider-electric.co.in\n" + "E & OE. CIN: U74899DL1995PTC06581\n", fontBold6)));
        document.add(nTable);

        //...........................................................................................................//

        Paragraph page2 = new Paragraph("Page : 2 of 2", fontBold7);
        page2.setAlignment(Paragraph.ALIGN_RIGHT);
        document.add(page2);

        document.close();
    }

}