package com.schneider.api.dto;

import javax.persistence.Column;
import java.util.List;

public class SubmitInvoiceDTO {

    private String version;
    private TranDtlsDTO tranDtlsDTO;
    private DocDtlsDTO docDtlsDTO;
    private SellerDtlsDTO sellerDtlsDTO;
    private BuyerDtlsDTO buyerDtlsDTO;
    private DispDtlsDTO dispDtlsDTO;
    private ShipDtlsDTO shipDtlsDTO;
    private List<IteamDTO> itemList;
    private ValDtlsDTO valDtlsDTO;
    private PayDtlsDTO payDtlsDTO;
    private RefDtlsDTO refDtlsDTO;
    private List<AddlDocDetailsDTO> addlDocDtls;
    private ExpDtlsDTO expDtlsDTO;
    private EwbDtlsDTO ewbDtlsDTO;


    private String name;

    private String address;

    private String deliveryDate;

    private int qty;

    private double price;

    private String deliveryNo;

    public String getVersion() {
        return version;
    }

    public void setVersion(String Version) {
        this.version = Version;
    }

    public TranDtlsDTO getTranDtls() {
        return tranDtlsDTO;
    }

    public void setTranDtls(TranDtlsDTO tranDtlsDTO) {
        this.tranDtlsDTO = tranDtlsDTO;
    }

    public DocDtlsDTO getDocDtls() {
        return docDtlsDTO;
    }

    public void setDocDtls(DocDtlsDTO docDtlsDTO) {
        this.docDtlsDTO = docDtlsDTO;
    }

    public SellerDtlsDTO getSellerDtls() {
        return sellerDtlsDTO;
    }

    public void setSellerDtls(SellerDtlsDTO sellerDtlsDTO) {
        this.sellerDtlsDTO = sellerDtlsDTO;
    }

    public BuyerDtlsDTO getBuyerDtls() {
        return buyerDtlsDTO;
    }

    public void setBuyerDtls(BuyerDtlsDTO buyerDtlsDTO) {
        this.buyerDtlsDTO = buyerDtlsDTO;
    }

    public DispDtlsDTO getDispDtls() {
        return dispDtlsDTO;
    }

    public void setDispDtls(DispDtlsDTO dispDtlsDTO) {
        this.dispDtlsDTO = dispDtlsDTO;
    }

    public ShipDtlsDTO getShipDtls() {
        return shipDtlsDTO;
    }

    public void setShipDtls(ShipDtlsDTO shipDtlsDTO) {
        this.shipDtlsDTO = shipDtlsDTO;
    }

    public List<IteamDTO> getItemList() {
        return itemList;
    }

    public void setItemList(List<IteamDTO> itemList) {
        this.itemList = itemList;
    }

    public ValDtlsDTO getValDtls() {
        return valDtlsDTO;
    }

    public void setValDtls(ValDtlsDTO valDtlsDTO) {
        this.valDtlsDTO = valDtlsDTO;
    }

    public PayDtlsDTO getPayDtls() {
        return payDtlsDTO;
    }

    public void setPayDtls(PayDtlsDTO payDtlsDTO) {
        this.payDtlsDTO = payDtlsDTO;
    }

    public RefDtlsDTO getRefDtls() {
        return refDtlsDTO;
    }

    public void setRefDtls(RefDtlsDTO refDtlsDTO) {
        this.refDtlsDTO = refDtlsDTO;
    }

    public List<AddlDocDetailsDTO> getAddlDocDtls() {
        return addlDocDtls;
    }

    public void setAddlDocDtls(List<AddlDocDetailsDTO> addlDocDtls) {
        this.addlDocDtls = addlDocDtls;
    }

    public ExpDtlsDTO getExpDtls() {
        return expDtlsDTO;
    }

    public void setExpDtls(ExpDtlsDTO expDtlsDTO) {
        this.expDtlsDTO = expDtlsDTO;
    }

    public EwbDtlsDTO getEwbDtls() {
        return ewbDtlsDTO;
    }

    public void setEwbDtls(EwbDtlsDTO ewbDtlsDTO) {
        this.ewbDtlsDTO = ewbDtlsDTO;
    }

    public TranDtlsDTO getTranDtlsDTO() {
        return tranDtlsDTO;
    }

    public void setTranDtlsDTO(TranDtlsDTO tranDtlsDTO) {
        this.tranDtlsDTO = tranDtlsDTO;
    }

    public DocDtlsDTO getDocDtlsDTO() {
        return docDtlsDTO;
    }

    public void setDocDtlsDTO(DocDtlsDTO docDtlsDTO) {
        this.docDtlsDTO = docDtlsDTO;
    }

    public SellerDtlsDTO getSellerDtlsDTO() {
        return sellerDtlsDTO;
    }

    public void setSellerDtlsDTO(SellerDtlsDTO sellerDtlsDTO) {
        this.sellerDtlsDTO = sellerDtlsDTO;
    }

    public BuyerDtlsDTO getBuyerDtlsDTO() {
        return buyerDtlsDTO;
    }

    public void setBuyerDtlsDTO(BuyerDtlsDTO buyerDtlsDTO) {
        this.buyerDtlsDTO = buyerDtlsDTO;
    }

    public DispDtlsDTO getDispDtlsDTO() {
        return dispDtlsDTO;
    }

    public void setDispDtlsDTO(DispDtlsDTO dispDtlsDTO) {
        this.dispDtlsDTO = dispDtlsDTO;
    }

    public ShipDtlsDTO getShipDtlsDTO() {
        return shipDtlsDTO;
    }

    public void setShipDtlsDTO(ShipDtlsDTO shipDtlsDTO) {
        this.shipDtlsDTO = shipDtlsDTO;
    }

    public ValDtlsDTO getValDtlsDTO() {
        return valDtlsDTO;
    }

    public void setValDtlsDTO(ValDtlsDTO valDtlsDTO) {
        this.valDtlsDTO = valDtlsDTO;
    }

    public PayDtlsDTO getPayDtlsDTO() {
        return payDtlsDTO;
    }

    public void setPayDtlsDTO(PayDtlsDTO payDtlsDTO) {
        this.payDtlsDTO = payDtlsDTO;
    }

    public RefDtlsDTO getRefDtlsDTO() {
        return refDtlsDTO;
    }

    public void setRefDtlsDTO(RefDtlsDTO refDtlsDTO) {
        this.refDtlsDTO = refDtlsDTO;
    }

    public ExpDtlsDTO getExpDtlsDTO() {
        return expDtlsDTO;
    }

    public void setExpDtlsDTO(ExpDtlsDTO expDtlsDTO) {
        this.expDtlsDTO = expDtlsDTO;
    }

    public EwbDtlsDTO getEwbDtlsDTO() {
        return ewbDtlsDTO;
    }

    public void setEwbDtlsDTO(EwbDtlsDTO ewbDtlsDTO) {
        this.ewbDtlsDTO = ewbDtlsDTO;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getDeliveryDate() {
        return deliveryDate;
    }

    public void setDeliveryDate(String deliveryDate) {
        this.deliveryDate = deliveryDate;
    }

    public int getQty() {
        return qty;
    }

    public void setQty(int qty) {
        this.qty = qty;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public String getDeliveryNo() {
        return deliveryNo;
    }

    public void setDeliveryNo(String deliveryNo) {
        this.deliveryNo = deliveryNo;
    }
}