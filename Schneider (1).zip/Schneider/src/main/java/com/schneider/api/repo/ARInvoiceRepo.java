package com.schneider.api.repo;

import com.schneider.api.model.ARInvoiceDetails;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;

@Repository
public interface ARInvoiceRepo extends JpaRepository<ARInvoiceDetails, Integer> {

    /**
     * NATIVE Query to fetch ARInvoiceDetails on the basis of date
     * @param from
     * @param to
     * @return AR Analyst Dashboard search result on the basis of date
     */

    @Query("SELECT d FROM ARInvoiceDetails d WHERE d.invoiceDate BETWEEN :from AND :to")
    public List<ARInvoiceDetails> getDataByInvoiceDate(@Param("from") Date from, @Param("to") Date to);


    @Query(value = "select d.invoiceNo from ARInvoiceDetails d where d.status='INVOICE_RECEIVED'")
    public List<String> getDataByStatus();

}