package com.schneider.api.service;

import com.schneider.api.dto.ARInvoiceDetailsDto;
import com.schneider.api.dto.SubmitInvoiceDTO;
import com.schneider.api.model.ARInvoiceDetails;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.text.ParseException;
import java.util.Date;
import java.util.List;

public interface ARInvoiceService {

    public ARInvoiceDetails saveARInvoiceDetails(SubmitInvoiceDTO arInvoice) throws ParseException;

    public List<ARInvoiceDetails> getAllARInvoiceDetails(Integer pageNumber, Integer pageSize);

    public List<ARInvoiceDetailsDto> getDataByInvoiceDate(Date fromDate, Date toDate);

    public Resource loadFileAsResource(String fileName) throws IOException;

    public List<String> getInvoiceNoByStatus();
}