package com.schneider.security.jwt;

import com.schneider.security.model.User;
import io.jsonwebtoken.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Component;

import java.util.Date;

import static java.lang.System.currentTimeMillis;


@Component
public class JwtTokenUtil {

    private static final Logger LOG = LoggerFactory.getLogger(JwtTokenUtil.class);
    private static final long EXPIRE_DURATION = 24 * 60 * 60 * 1000; // 24 hour
    // private static final long EXPIRE_DURATION = currentTimeMillis() + 1000*60*30;// 30 min
    @Value("${app.jwt.secret}")
    private String SECRET_KEY;

    /**
     * @param user
     * @return generates access token for username
     */
    public String generateAccessToken(User user) {

        return Jwts.builder()
                .setSubject(String.format("%s,%s", user.getUserId(), user.getUsername()))
                .claim("roles", user.getRole().toString())
                .setIssuedAt(new Date())
                .setExpiration(new Date(currentTimeMillis() + EXPIRE_DURATION))
                .signWith(SignatureAlgorithm.HS512, SECRET_KEY)
                .compact();
    }

    /**
     * @param token
     * @return validated token
     */
    public boolean validateAccessToken(String token) {
        try {
            Jwts.parser().setSigningKey(SECRET_KEY).parseClaimsJws(token);
            return true;
        } catch (ExpiredJwtException ex) {
            LOG.error("JWT expired", ex.getMessage());
        } catch (IllegalArgumentException ex) {
            LOG.error("Token is null, empty or only whitespace", ex.getMessage());
        } catch (MalformedJwtException ex) {
            LOG.error("JWT is invalid", ex);
        } catch (UnsupportedJwtException ex) {
            LOG.error("JWT is not supported", ex);
        } catch (SignatureException ex) {
            LOG.error("Signature validation failed");
        }

        return false;
    }

    public String getSubject(String token) {
        return parseClaims(token).getSubject();
    }

    public Claims parseClaims(String token) {
        return Jwts.parser()
                .setSigningKey(SECRET_KEY)
                .parseClaimsJws(token)
                .getBody();
    }

    /**
     * @return generates token for CliendId code by Ankit
     */

    public String generateAccessClientToken() {

        return Jwts.builder()
                .setSubject(String.format(""))
                .setIssuedAt(new Date())
                .setExpiration(new Date(currentTimeMillis() + EXPIRE_DURATION))
                .signWith(SignatureAlgorithm.HS512, SECRET_KEY)
                .compact();
    }

}