package com.schneider.security.service;

import com.schneider.security.model.User;
import com.schneider.security.model.UserDTO;
import com.schneider.security.repository.RoleRepository;
import com.schneider.security.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
//import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.Date;

@Service
@Transactional
public class UserServiceImpl {

    @Autowired
    private UserRepository userRepository;

    //    @Autowired
    //    private PasswordEncoder passwordEncoder;
    @Autowired
    RoleRepository roleRepository;

    /**
     * @param userDTO
     * @return storing user with role mapped with it
     */
    public User save(UserDTO userDTO) {
        User user = new User();
        user.setUserId(userDTO.getId());
        user.setUsername(userDTO.getUsername());
        user.setFirstName(userDTO.getFirstName());
        user.setLastName(userDTO.getLastName());
        // String encodedPassword = passwordEncoder.encode(userDTO.getPassword());
        // user.setPassword(encodedPassword);
        user.setPassword(userDTO.getPassword());
        user.setRole(roleRepository.getByRoleName(userDTO.getRole()));
        user.setCreatedDate(new Date());
        user.setModifiedDate(new Date());
        return userRepository.save(user);
    }


    /**
     * Validating username & password before login
     */
    public User validateUser(String username, String password) {
        return userRepository.validateUser(username, password);
    }

}