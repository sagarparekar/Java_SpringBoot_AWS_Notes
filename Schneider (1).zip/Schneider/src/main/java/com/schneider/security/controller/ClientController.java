package com.schneider.security.controller;

import com.schneider.security.jwt.JwtTokenUtil;
import com.schneider.security.model.AuthResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.web.bind.annotation.*;

@CrossOrigin
@RestController
@RequestMapping("/schneider/client")
public class ClientController {

    private static final Logger log = LoggerFactory.getLogger(ClientController.class);

    @Autowired
    AuthenticationManager authManager;
    @Autowired
    JwtTokenUtil jwtUtil;

    /**
     * API to generate client token on the basis of clientID, Holded not required for this use case
     * TODO Validation pending
     * Auther : Sagar
     */

    @PostMapping(path = "/authenticate_client", consumes = "application/x-www-form-urlencoded")
    public ResponseEntity<?> authenticateClient(@RequestParam("clientID") String value1) {
        try {

            System.out.println("The client is is :" + value1);
            String accessToken = jwtUtil.generateAccessClientToken();
            AuthResponse response = new AuthResponse(accessToken);
            return ResponseEntity.ok("Client authentication token is" + ": " + accessToken);

        } catch (BadCredentialsException ex) {
            log.warn("Username or password is wrong");
            return ResponseEntity.status(HttpStatus.UNAUTHORIZED).build();
        }
    }
}