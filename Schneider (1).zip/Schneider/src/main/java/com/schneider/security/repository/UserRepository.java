package com.schneider.security.repository;

import com.schneider.security.model.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface UserRepository extends JpaRepository<User,Integer> {

    Optional<User> findByUsername(String username);
    @Query(value="select u from User u left join Role r on u.role=r.roleId where u.username = :username and u.password= :password")
    public User validateUser(@Param("username") String username, @Param("password") String password);


}