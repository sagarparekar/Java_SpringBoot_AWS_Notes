package com.schneider.security.controller;


import com.schneider.security.model.UserDTO;
import com.schneider.security.service.UserServiceImpl;
import org.springframework.beans.factory.annotation.Autowired;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * Not part of this use case , can be used from backend
 */
@CrossOrigin
@RestController
public class UserController {

    @Autowired
    private UserServiceImpl service;

    /**
     * @param userDTO
     * @return ResponseEntity new user created
     * Author - Sagar
     */
    @PostMapping("/createUser")
    public ResponseEntity<?> createUser(@RequestBody UserDTO userDTO) {
        service.save(userDTO);
        return ResponseEntity.ok().body("User Created Successfully: \n" + "Username: " + userDTO.getUsername() + "\n" + "Password: " + userDTO.getPassword() + "\n" + "Role: " + userDTO.getRole());
    }


}